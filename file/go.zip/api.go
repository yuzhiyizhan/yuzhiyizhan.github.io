package main

import (
	"fmt"
	"github.com/Esbiya/requests"
	"github.com/bitly/go-simplejson"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"io"
	"net/http"
)

func SimpleJson(b io.ReadCloser) (*simplejson.Json, error) {
	return simplejson.NewFromReader(b)
}

func completions() *gin.Engine {
	r := gin.Default()
	r.Use(cors.New(cors.Config{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders: []string{"Origin", "Content-Type", "Authorization"},
	}))
	r.POST("completions", func(context *gin.Context) {
		url := "https://api.openai.com/v1/completions"
		jsons := make(map[string]interface{})
		context.BindJSON(&jsons)
		key := jsons["key"]
		Bearer := fmt.Sprintf("%s %s", "Bearer ", key)
		headers := requests.Headers{
			"Accept":          "application/json",
			"User-Agent":      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
			"Content-Type":    "application/x-www-form-urlencoded",
			"Accept-Language": "zh-CN,zh;q=0.9",
			"Authorization":   Bearer,
		}
		model := jsons["model"]
		prompt := jsons["prompt"]
		max_tokens := jsons["max_tokens"]
		temperature := jsons["temperature"]
		frequency_penalty := jsons["frequency_penalty"]
		presence_penalty := jsons["presence_penalty"]
		top_p := jsons["top_p"]

		data := requests.Payload{
			"model":             model,
			"prompt":            prompt,
			"max_tokens":        max_tokens,
			"temperature":       temperature,
			"frequency_penalty": frequency_penalty,
			"presence_penalty":  presence_penalty,
			"top_p":             top_p,
		}

		resp := requests.Post(url, headers, data)
		if resp.Error() != nil {
			log.Fatal(resp.Error())
		}
		//js, _ := resp.JSON()
		//log.Println(js)

		//req := url.NewRequest()
		//headers := url.NewHeaders()
		//jsons := make(map[string]interface{})
		//context.BindJSON(&jsons)
		//key := jsons["key"]
		//model := jsons["model"]
		//prompt := jsons["prompt"]
		//max_tokens := jsons["max_tokens"]
		//temperature := jsons["temperature"]
		//frequency_penalty := jsons["frequency_penalty"]
		//presence_penalty := jsons["presence_penalty"]
		//top_p := jsons["top_p"]
		//req.Json = map[string]interface{}{
		//	"model":             model,
		//	"prompt":            prompt,
		//	"max_tokens":        max_tokens,
		//	"temperature":       temperature,
		//	"frequency_penalty": frequency_penalty,
		//	"presence_penalty":  presence_penalty,
		//	"top_p":             top_p,
		//}
		//Bearer := fmt.Sprintf("%s %s", "Bearer ", key)
		//headers.Set("Authorization", Bearer)
		//req.Headers = headers
		//req.Ja3 = ""
		//
		//r, err := requests.Post("https://api.openai.com/v1/completions", req)
		//if err != nil {
		//	fmt.Println("err", err)
		//}
		//log.Println(r.Text)
		//js, _ := r.Json()
		js, _ := SimpleJson(resp.Body)
		context.JSON(http.StatusOK, js)
	})
	return r
}

func main() {
	r := completions()
	r.Run("0.0.0.0:7546")
}
