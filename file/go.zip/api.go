package main

import (
	"fmt"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/yuzhiyizhan/requests"
	"github.com/yuzhiyizhan/requests/url"
	"net/http"
)

func completions() *gin.Engine {
	r := gin.Default()
	r.Use(cors.New(cors.Config{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders: []string{"Origin", "Content-Type", "Authorization"},
	}))
	r.POST("completions", func(context *gin.Context) {
		req := url.NewRequest()
		headers := url.NewHeaders()
		jsons := make(map[string]interface{})
		context.BindJSON(&jsons)
		key := jsons["key"]
		model := jsons["model"]
		prompt := jsons["prompt"]
		max_tokens := jsons["max_tokens"]
		temperature := jsons["temperature"]
		frequency_penalty := jsons["frequency_penalty"]
		presence_penalty := jsons["presence_penalty"]
		top_p := jsons["top_p"]
		req.Json = map[string]interface{}{
			"model":             model,
			"prompt":            prompt,
			"max_tokens":        max_tokens,
			"temperature":       temperature,
			"frequency_penalty": frequency_penalty,
			"presence_penalty":  presence_penalty,
			"top_p":             top_p,
		}
		Bearer := fmt.Sprintf("%s %s", "Bearer ", key)
		headers.Set("Authorization", Bearer)
		req.Headers = headers

		r, err := requests.Post("https://api.openai.com/v1/completions", req)
		if err != nil {
			fmt.Println(err)
		}
		js, _ := r.Json()
		context.JSON(http.StatusOK, js)
	})
	return r
}

func main() {
	r := completions()
	r.Run("0.0.0.0:7546")
}
