const express = require('express');
const bodyParser = require('body-parser');
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;
const cors = require('cors');
const XEAjax = require('xe-ajax')


const app = express();
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(cors());
app.post('/completions', async (request, response) => {
    let datas = request.body
    let keys = datas.key
    delete datas.key

    async function getResponse() {
        return XEAjax.ajax({
            url: 'https://api.openai.com/v1/completions',
            method: 'POST',
            body: datas,
            headers: {
                "Authorization": `Bearer ${keys}`,
            },
        }).then(response => {
            let text = JSON.parse(response._body)
            return text
        }).catch(e => {
            return {error: e.message}
        })
    }
    const data = await getResponse();
    response.send(data)
});

if (cluster.isMaster) {
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }
    cluster.on('exit', (worker, code, signal) => {
    });
} else {
    const port = 7546;
    app.listen(port, () => {
        console.log(`已启动，端口 : ${port}`);
    });
}
