const XEAjax = require('xe-ajax')


async function init() {
    let list = await XEAjax.get('https://tls.peet.ws/api/all')
    console.log(list)
}

init()