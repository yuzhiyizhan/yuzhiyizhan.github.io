import httpx
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from loguru import logger
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def api_completions(message):
    url = "https://api.openai.com/v1/completions"
    async with httpx.AsyncClient() as client:
        datas = message.dict()
        keys = datas["key"]
        del datas["key"]
        response = await client.post(
            url,
            json=datas,
            headers={
                "Authorization": f"Bearer {keys}",
            },
            timeout=60,
        )
        return response.json()
        
@app.post("/")
async def completions(message):
    print(message)
    logger.debug(message)
    res = await api_completions(message)
    return res
    
    
uvicorn.run("app:app", host="0.0.0.0", port=7546)
    
    
    